package com.akh.controller;

import org.springframework.security.access.annotation.Secured;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HomeController {
	
	@GetMapping("/auth/welcome")
	public String home() {
		return "Home Page";
	}
	
	@GetMapping("auth/admin/two")
	//@Secured("ROLE_ADMIN")
	@PreAuthorize("hasAuthority('ROLE_ADMIN')")
	public String adminTwo() {
		return "Admin Page Admin 2";
	}
	
	@GetMapping("auth/admin")
	//@Secured("ROLE_ADMIN")
	@PreAuthorize("hasAuthority('ROLE_ADMIN')")
	public String admin() {
		return "Admin Page";
	}
	
	@GetMapping("auth/user")
	//@Secured("ROLE_USER")
	@PreAuthorize("hasAuthority('ROLE_USER')")
	public String user() {
		return "User Page";
	}

}
